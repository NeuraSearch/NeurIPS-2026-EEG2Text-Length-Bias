from abc import abstractmethod
from argparse import Namespace
from typing import Any, Dict, Union

from omegaconf import DictConfig


class RunnerInterface:
    def __init__(self):
        print("Initializing RunnerInterface class")

    @abstractmethod
    def run(self,args: Union[Namespace, Dict[str, Any],DictConfig]):
        pass