from abc import abstractmethod
from argparse import Namespace
from typing import Any

from omegaconf import DictConfig


class ModelInterface:

    def __init__(self,args : Namespace | dict[str, Any] | DictConfig):
        self.args = args

    @abstractmethod
    def initialize_model(self ):
        pass
