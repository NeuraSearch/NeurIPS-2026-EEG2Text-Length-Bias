from abc import abstractmethod
from argparse import Namespace
from typing import Any

import torch
from numpy._typing import NDArray
from omegaconf import DictConfig
from torch import nn

from Components.ModelLayer.ModelInterface import ModelInterface


class DeepLearningModelInterface(ModelInterface,nn.Module):



    def __init__(self,args : Namespace | dict[str, Any] | DictConfig):

        super().__init__(args)


    def initialize_model(self):
        pass

    @abstractmethod
    def forward(self, x : torch.Tensor | NDArray) -> torch.Tensor | NDArray:
        pass