from abc import abstractmethod

import torch
from numpy._typing import NDArray


class AttentionInterface:

    def __init__(self):
        print("Initializing attention")

    @abstractmethod
    def forward(self , x : torch.Tensor | NDArray) -> torch.Tensor | NDArray:
        pass