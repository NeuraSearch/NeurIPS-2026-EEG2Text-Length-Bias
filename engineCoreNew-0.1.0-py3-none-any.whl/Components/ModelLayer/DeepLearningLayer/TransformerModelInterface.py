from argparse import Namespace
from typing import Any

import torch
from numpy._typing import NDArray

from omegaconf import DictConfig

from Components.Factories.AttentionFactory import AttentionFactory
from Components.ModelLayer.DeepLearningLayer.DeepLearningModelInterface import DeepLearningModelInterface
from Toolbox.tools import convert_args_to_dict


class TransformerModelInterface(DeepLearningModelInterface):



    def __init__(self,args :  Namespace | dict[str, Any] | DictConfig):
        super().__init__(args)
        args = convert_args_to_dict(args)
        if "attentionImplementation" in args:
            self.attentionFactory = AttentionFactory()
            self.attention = self.attentionFactory.construct_implementation(args["attentionImplementation"],args)


    def forward(self, x: torch.Tensor | NDArray) -> torch.Tensor | NDArray:
        pass