from argparse import Namespace
from typing import Any

from omegaconf import DictConfig

from Components.ModelLayer.ModelInterface import ModelInterface


class MachineLearningModelInterface(ModelInterface):

    def __init__(self,args : Namespace | dict[str, Any] | DictConfig):
        super().__init__(args)

    #
    def initialize_model(self):
        pass