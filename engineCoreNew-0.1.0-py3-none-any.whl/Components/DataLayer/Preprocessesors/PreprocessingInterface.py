from abc import abstractmethod
from argparse import Namespace
from typing import Union, Any, Dict

from numpy import ndarray
from omegaconf import DictConfig


class PreprocessesingInterface:

    def __init__(self):
        pass

    @abstractmethod
    def preprocess(self, data: list | ndarray | Dict[str,Any],args: Namespace | DictConfig | Dict[str, Any])->list | ndarray | Dict[str,Any]:
        pass