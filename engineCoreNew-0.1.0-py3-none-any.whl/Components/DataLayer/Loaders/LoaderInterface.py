from abc import abstractmethod
from argparse import Namespace
from typing import Any, Dict, Union

from numpy import ndarray
from omegaconf import DictConfig


class LoaderInterface:

    def __init__(self):
        pass

    @abstractmethod
    def load_data(self,args: Namespace | DictConfig | Dict[str, Any])->Dict[str,Any] | list| ndarray:
        pass