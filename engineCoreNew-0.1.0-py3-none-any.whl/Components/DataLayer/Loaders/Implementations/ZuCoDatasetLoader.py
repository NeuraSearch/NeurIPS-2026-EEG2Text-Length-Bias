import json
import os
import pickle
from argparse import Namespace
from typing import Dict, Any, Union, Tuple

import numpy as np
from omegaconf import DictConfig
from sklearn.model_selection import train_test_split

from Components.DataLayer.Loaders.LoaderInterface import LoaderInterface
from Components.DataLayer.Preprocessesors import PreprocessingInterface
from Utility.Utilities import Utilities


class ZuCoDatasetLoader(LoaderInterface):


    def __init__(self, args: Union[Namespace,DictConfig,Dict[str, Any]],eeg_resampler: PreprocessingInterface =None):

        super().__init__()
        self.target_key = args["running_args"]["target_key"]
        zuco_1_subjects = ["ZAB", "ZDM", "ZDN", "ZGW", "ZJM", "ZJN", "ZJS", "ZKB", "ZKH", "ZKW", "ZMG", "ZPH"]
        zuco_2_subjects = ["YAG", "YAK", "YDG", "YDR", "YFR", "YFS", "YHS", "YIS", "YLS", "YMD", "YMS", "YRH", "YRK",
                           "YRP",
                           "YSD", "YSL", "YTL"]
        zuco_1_subjects_2 = ["ZAB", "ZDM", "ZDN", "ZGW", "ZJM", "ZJN", "ZKB", "ZKH", "ZKW", "ZMG", "ZPH"]
        tasks = self.define_desired_taks(
            args["running_args"]["task_definition"],
            zuco_1_subjects,
            zuco_1_subjects_2,
            zuco_2_subjects,
            args["running_args"]["task1_path"],
            args["running_args"]["task2_path"],
            args["running_args"]["task2v2_path"]
        )
        self.data = self.read_data(tasks)
        self.utilities = Utilities()
        self.eeg_resampler = eeg_resampler

    def read_data(self, tasks: Dict[str,Any]) -> Dict[str, Any]:
        print("Reading data")
        """

        Args:
            tasks: a dictionary contain the task name as key and the path to the json file as value where the task data are stored

        Returns:
            a dictionary that has the format:
            {
                "task1": "subject1":{[{"sentence": "sentence1", "eeg": [[1,2,3],[4,5,6],...], "word": "word1"},
                          {"sentence": "sentence2", "eeg": [[1,2,3],[4,5,6],...], "word": "word2"},
                          ...
                         ],},
                         subject2":{[{"sentence": "sentence1", "eeg": [[1,2,3],[4,5,6],...], "word": "word1"},
                          {"sentence": "sentence2", "eeg": [[1,2,3],[4,5,6],...], "word": "word2"},
                          ...
                         ],},
                "task2": "subject1":{[{"sentence": "sentence1", "eeg": [[1,2,3],[4,5,6],...], "word": "word1"},
                          {"sentence": "sentence2", "eeg": [[1,2,3],[4,5,6],...], "word": "word2"},
                          ...
                         ],},
                         subject2":{[{"sentence": "sentence1", "eeg": [[1,2,3],[4,5,6],...], "word": "word1"},
                          {"sentence": "sentence2", "eeg": [[1,2,3],[4,5,6],...], "word": "word2"},
                          ...
                         ],},
                ...
            }
        """
        data = {}
        for entry in tasks:
            if tasks[entry]["path"] is not None:
                path = tasks[entry]["path"]
                if "json" in path:
                    with open(path, "r") as f:
                        data[entry] = json.load(f)
                elif "pickle" in path or "pkl" in path:
                    with open(path, "rb") as f:
                        data[entry] = pickle.load(f)
                elif ".mat" in path:
                    #TODO needs to convert first then load json
                    pass

        return data

    def gather_tokenize_content(self, word_data: Union[Dict[str, Any], list, np.ndarray]) -> Union[list, np.ndarray]:
        tokenized_content = []

        for word in word_data:
            tokenized_content.append(word["content"])

        return tokenized_content

    def get_feature_concatenation(self, data_to_use: Union[Dict[str, Any], list, np.ndarray], index) -> Union[
        list, np.ndarray]:
        if type(data_to_use) == list:
            features = [
                data_to_use[index]["mean_a1"],
                data_to_use[index]["mean_a2"],
                data_to_use[index]["mean_b1"],
                data_to_use[index]["mean_b2"],
                data_to_use[index]["mean_g1"],
                data_to_use[index]["mean_g2"],
                data_to_use[index]["mean_t1"],
                data_to_use[index]["mean_t2"],

            ]


        else:
            features = [
                data_to_use["mean_a1"][index],
                data_to_use["mean_a2"][index],
                data_to_use["mean_b1"][index],
                data_to_use["mean_b2"][index],
                data_to_use["mean_g1"][index],
                data_to_use["mean_g2"][index],
                data_to_use["mean_t1"][index],
                data_to_use["mean_t2"][index],

            ]
        features = self.utilities.remove_nan(features)
        if len(features) > 0:
            features = np.concatenate(features).tolist()
        return features

    def get_raw_eeg_sentence_data(self, desired_tasks: Union[Dict[str, Any], list, np.ndarray]) -> Dict[str, Any]:
        desired_data = {}
        print("The tasks are")
        print(self.data.keys())
        for task in self.data:
            if task in desired_tasks:
                task_data = self.data[task]
                for subject in task_data:
                    data_to_use = task_data[subject]

                    if type(data_to_use) == list:
                        num_sentences = len(data_to_use)
                    else:
                        num_sentences = len(data_to_use["rawData"])
                    for i in range(num_sentences):
                        is_word_non_nan = True
                        if type(data_to_use) == list:
                            raw_data = data_to_use[i]["rawData"]
                            content = data_to_use[i]["content"]
                        else:
                            raw_data = data_to_use["rawData"][i]
                            content = data_to_use["content"][i]
                            if type(data_to_use["word"][i]) != list and type(data_to_use["word"][i]) != dict:
                                dimesnions = self.utilities.dim(data_to_use["word"][i])

                                if len(dimesnions) > 0:
                                    tokenized_content = data_to_use["word"][i]["content"]
                                else:
                                    tokenized_content = ""
                                    is_word_non_nan = False
                            else:
                                tokenized_content = data_to_use["word"][i]["content"]
                            # if type(tokenized_content) == list:
                            #     tokenized_content = " ".join(tokenized_content)
                        if subject not in desired_data:
                            desired_data[subject] = []
                        dimensions = self.utilities.dim(raw_data)
                        if len(dimensions) > 0:
                            if type(data_to_use) == list:
                                tokenized_content = self.gather_tokenize_content(data_to_use[i]["word"])
                            if is_word_non_nan:
                                if len(dimensions) == 1:
                                    raw_data = np.array([raw_data])
                                desired_data[subject].append({"sentence": content, "rawData": raw_data,
                                                              "tokenized_sentence": tokenized_content, "task": task,
                                                              "subject": subject})
                                is_word_non_nan = True
        return desired_data

    def define_desired_taks(self, task: str, zuco_1_subjects: Union[list, np.ndarray],
                            zuco_1_subjects_2: Union[list, np.ndarray], zuco_2_subjects: Union[list, np.ndarray],
                            task1_path: str, task2_path: str,
                            task2v2_path: str) -> Dict[str, Any]:
        desired_tasks = {}
        argument_tasks = task.split("_")
        if "task1" in argument_tasks:
            desired_tasks["task1"] = {
                "path": task1_path,
                "subjects": zuco_1_subjects
            }
        if "task2" in argument_tasks:
            desired_tasks["task2"] = {
                "path": task2_path,
                "subjects": zuco_1_subjects_2
            }
        if "task2v2" in argument_tasks:
            desired_tasks["task2v2"] = {
                "path": task2v2_path,
                "subjects": zuco_2_subjects
            }
        return desired_tasks

    def get_features(self, desired_tasks: Union[Dict[str, Any], list, np.ndarray, str]) -> Dict[str, Any]:
        desired_data = {}
        print("Getting features")
        for task in self.data:
            if task in desired_tasks:
                task_data = self.data[task]
                for subject in task_data:
                    data_to_use = task_data[subject]

                    if type(data_to_use) == list:
                        num_sentences = len(data_to_use)
                    else:
                        num_sentences = len(data_to_use["rawData"])
                    for i in range(num_sentences):
                        is_word_non_nan = True
                        if type(data_to_use) == list:
                            raw_data = self.get_feature_concatenation(data_to_use, i)
                            content = data_to_use[i]["content"]
                        else:
                            raw_data = self.get_feature_concatenation(data_to_use, i)
                            content = data_to_use["content"][i]
                            if type(data_to_use["word"][i]) != list and type(data_to_use["word"][i]) != dict:
                                dimesnions = self.utilities.dim(data_to_use["word"][i])

                                if len(dimesnions) > 0:
                                    tokenized_content = data_to_use["word"][i]["content"]
                                else:
                                    tokenized_content = ""
                                    is_word_non_nan = False
                            else:
                                tokenized_content = data_to_use["word"][i]["content"]
                            # if type(tokenized_content) == list:
                            #     tokenized_content = " ".join(tokenized_content)
                        if subject not in desired_data:
                            desired_data[subject] = []
                        dimensions = self.utilities.dim(raw_data)
                        if len(dimensions) > 0 and raw_data != []:
                            if type(data_to_use) == list:
                                tokenized_content = self.gather_tokenize_content(data_to_use[i]["word"])
                            if is_word_non_nan:
                                if len(dimensions) == 1:
                                    raw_data = np.array([raw_data])
                                desired_data[subject].append(
                                    {"sentence": content, "rawData": raw_data,
                                     "tokenized_sentence": tokenized_content,
                                     "task": task, "subject": subject})
                                is_word_non_nan = True
        return desired_data

    def load_data(self, args: Union[Namespace,DictConfig,Dict[str, Any]]) -> Union[Dict[str, Any], list, np.ndarray]:
        zuco_1_subjects = ["ZAB", "ZDM", "ZDN", "ZGW", "ZJM", "ZJN", "ZJS", "ZKB", "ZKH", "ZKW", "ZMG", "ZPH"]
        zuco_2_subjects = ["YAG", "YAK", "YDG", "YDR", "YFR", "YFS", "YHS", "YIS", "YLS", "YMD", "YMS", "YRH",
                           "YRK",
                           "YRP",
                           "YSD", "YSL", "YTL"]
        zuco_1_subjects_2 = ["ZAB", "ZDM", "ZDN", "ZGW", "ZJM", "ZJN", "ZKB", "ZKH", "ZKW", "ZMG", "ZPH"]

        desired_tasks = self.define_desired_taks(
            args["running_args"]["task_definition"],
            zuco_1_subjects,
            zuco_1_subjects_2,
            zuco_2_subjects,
            args["running_args"]["task1_path"],
            args["running_args"]["task2_path"],
            args["running_args"]["task2v2_path"]
        )

        if args["running_args"]["desired_data_training"] == "raw":
            raw_sentences = self.get_raw_eeg_sentence_data(desired_tasks)
        else:
            raw_sentences = self.get_features(desired_tasks)
        print("Done loading")
        if args["running_args"]["subject"] == "ALL":
            raw_sentences_temp_train = []
            raw_sentences_test = []
            if args["running_args"]["split_mode"] == "one_subject":
                random_subject = np.random.choice(list(raw_sentences.keys()))
                raw_sentences_test = raw_sentences[random_subject]
                raw_sentences.pop(random_subject)
            for subject in raw_sentences:
                raw_sentences_temp_train.extend(raw_sentences[subject])
            raw_sentences_train = raw_sentences_temp_train
        else:
            raw_sentences_train = raw_sentences[args["running_args"]["subject"]]
        # whole_data = pad_or_cut_sequences(raw_sentences, int(args.max_length), key="rawData")

        targets = [entry[self.target_key] for entry in raw_sentences_train]
        input_data = [entry["rawData"] for entry in raw_sentences_train]
        all_sentences = targets
        if args["running_args"]["downsample"] and args["running_args"]["desired_encoder_model"] != "bendr":
            # TODO rethink of that implementation
            input_data = [self.eeg_resampler.preprocess(data, args) for data in input_data]

        if raw_sentences_test != []:
            targets_test = [entry[self.target_key] for entry in raw_sentences_test]
            input_data_test = [entry["rawData"] for entry in raw_sentences_test]
            if args["running_args"]["downsample"] and args["running_args"]["desired_encoder_model"] != "bendr":
                # TODO rethink of that implementation
                input_data_test = [self.eeg_resampler.preprocess(data, args) for data in input_data_test]
            all_sentences.extend(targets_test)

        max_character_length = max([len(sentence) for sentence in all_sentences])
        if not os.path.exists(args["running_args"]["vocab_file"]):
            texts = " ".join(all_sentences)
            vocab = list(set(texts))
            vocab_dict = {v: k for k, v in enumerate(vocab)}
            vocab_dict["|"] = vocab_dict[" "]
            del vocab_dict[" "]
            vocab_dict["[UNK]"] = len(vocab_dict)  # add "unknown" token
            vocab_dict["[PAD]"] = len(vocab_dict)
            with open(args["running_args"]["vocab_file"], 'w') as vocab_file:
                json.dump(vocab_dict, vocab_file)
        if args["running_args"]["split_mode"] != "one_subject":
            training_input, test_input, training_target, test_target, eval_input, eval_target = self.utilities.train_test_split_custom(
                input_data, targets, args["running_args"]["training_model"], args["running_args"]["split_mode"])
        else:
            training_input = input_data
            training_target = targets
            eval_input, test_input, eval_target, test_target = train_test_split(input_data_test, targets_test,
                                                                                test_size=0.5,
                                                                                random_state=42)

        training_input = self.utilities.format_to_numpy(training_input)
        eval_input = self.utilities.format_to_numpy(eval_input)
        test_input = self.utilities.format_to_numpy(test_input)
        dataset = {
            "training_input": training_input,
            "training_target": training_target,
            "eval_input": eval_input,
            "eval_target": eval_target,
            "test_input": test_input,
            "test_target": test_target,
            "max_length": int(args["running_args"]["max_length"]),
            "electrode_num": args["running_args"]["electrode_num"],
            "max_character_length": max_character_length,
        }
        return dataset

    def is_sentence_overallaping(self, sentence_obj: Dict[str, Any],
                                 gathered_data: Union[Dict[str, Any], list, np.ndarray]) -> bool:
        for gathered_data_obj in gathered_data:
            if sentence_obj["sentence"] == gathered_data_obj["sentence"] \
                    and sentence_obj["subject"] == gathered_data_obj["subject"] \
                    and sentence_obj["task"] != gathered_data_obj["task"]:
                return True
        return False

    def find_overlapping_sentences_per_subject(self, raw_sentences: Union[Dict[str, Any], list, np.ndarray]) -> Dict[
        str, Any]:
        overlap_dictionary = {}
        gathered_data = []
        for subject in raw_sentences:
            subject_data = raw_sentences[subject]
            for sentence in subject_data:
                if self.is_sentence_overallaping(sentence, gathered_data):
                    if subject not in overlap_dictionary:
                        overlap_dictionary[subject] = []
                    overlap_dictionary[subject].append(sentence)
                gathered_data.append(sentence)
        for subject in raw_sentences.keys():
            if subject in overlap_dictionary:
                all_subject_sentences = raw_sentences[subject]
                overlapping_sentences = overlap_dictionary[subject]
                overlap_percentage = len(overlapping_sentences) / len(all_subject_sentences)
                overlaping_sentences_num = len(overlapping_sentences)
                overlap_dictionary[subject]["overlap_percentage"] = overlap_percentage
                overlap_dictionary[subject]["overlaping_sentences_num"] = overlaping_sentences_num
        return overlap_dictionary

    def find_overlapping_sentences_accross_subjects(self,
                                                    raw_sentences: Union[Dict[str, Any], list, np.ndarray]) -> list:
        overlapping_sentences = []
        sentences_tested = []
        for subject in raw_sentences.keys():
            subject_data = raw_sentences[subject]
            for sentence in subject_data:
                if sentence["sentence"] not in sentences_tested:
                    sentences_tested.append(sentence["sentence"])
                else:
                    overlapping_sentences.append(sentence["sentence"])
                    sentences_tested.append(sentence["sentence"])
        return list(set(overlapping_sentences))

    def get_max_length_of_sentence(self, raw_sentences: Union[Dict[str, Any], list, np.ndarray]) -> Tuple[
        int, Dict[int, int]]:
        sentence_lengths = []
        length_distripution = {}
        for subject in raw_sentences:
            for sentence in raw_sentences[subject]:
                sentence_lengths.append(len(sentence["tokenized_sentence"]))
                if len(sentence["tokenized_sentence"]) not in length_distripution:
                    length_distripution[len(sentence["tokenized_sentence"])] = 0
                length_distripution[len(sentence["tokenized_sentence"])] += 1

        return max(sentence_lengths), length_distripution
