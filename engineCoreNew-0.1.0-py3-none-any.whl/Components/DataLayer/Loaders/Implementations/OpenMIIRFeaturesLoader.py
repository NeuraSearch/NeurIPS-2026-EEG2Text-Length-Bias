
import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder

from Components.DataLayer.Loaders.LoaderInterface import LoaderInterface
from Utility.ParticipantDataObject import ParticipantDataObject


class OpenMIRFeatureLoader(LoaderInterface):

    def __init__(self, args):
        super().__init__()
        self.path = args.file_path
        self.Type = args.Type
        self.window_size = args.window_size

    def one_hot_encode(self, y):
        enc = OneHotEncoder()
        enc.fit(y.reshape(-1, 1))
        combined_y = enc.transform(y.reshape(-1, 1)).toarray()

        return combined_y

    def read_data(self):
        print("Reading data")

        files = os.listdir(self.path)
        list_of_dfs = []
        list_of_subjects = []
        Type = self.Type

        for file in files:
            if Type == "Imagined":
                if "Imagined" in file:
                    list_of_subjects.append(file.split("_")[0])
                    df = pd.read_csv(os.path.join(self.path, file))
                    list_of_dfs.append(df)

            elif Type == "All":
                list_of_subjects.append(file.split("_")[0])
                df = pd.read_csv(os.path.join(self.path, file))
                list_of_dfs.append(df)

            elif Type == "Perceived":
                if "Imagined" not in file:
                    list_of_subjects.append(file.split("_")[0])
                    df = pd.read_csv(os.path.join(self.path, file))
                    list_of_dfs.append(df)

        return list_of_dfs, list_of_subjects

    def map_label_to_id(self, y, target_mapping):
        mapped_labels = []
        for i in range(len(y)):
            if y[i] in target_mapping.keys():
                mapped_labels.append(target_mapping[y[i]])

        mapped_labels = np.array(mapped_labels)
        return mapped_labels

    def ManageData(self):
        list_of_dfs, list_of_subjects = self.read_data()

        ParticipantObjectList = []
        for i in range(len(list_of_dfs)):
            participantData = ParticipantDataObject.ParticipantDataObject(list_of_dfs[i], list_of_subjects[i])
            ParticipantObjectList.append(participantData)

        X_list = []
        y_list = []
        for i in range(len(ParticipantObjectList)):
            X, y = ParticipantObjectList[i].create_X_Y(self.window_size)
            X_list.append(X)
            y_list.append(y)

        combined_X = np.concatenate(X_list, axis=0)
        combined_y = np.concatenate(y_list, axis=0)

        # map ids to same ids
        imagined_to_perceived = {13: 11, 23: 21, 33: 31, 43: 41, 113: 111, 123: 121, 133: 131, 143: 141, 213: 211,
                                 223: 221, 233: 231, 243: 241}
        for i in range(len(combined_y)):
            if combined_y[i] in imagined_to_perceived.keys():
                combined_y[i] = imagined_to_perceived[combined_y[i]]

        label_mapping = {11: 0, 21: 1, 31: 2, 41: 3, 111: 4, 121: 5, 131: 6, 141: 7, 211: 8, 221: 9, 231: 10,
                         241: 11}

        song_title_labeled = self.map_label_to_id(combined_y, label_mapping)
        combined_y = self.one_hot_encode(song_title_labeled)

        return combined_X, combined_y

