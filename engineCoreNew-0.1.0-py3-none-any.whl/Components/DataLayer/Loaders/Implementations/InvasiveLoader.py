import json
import os
import pickle
from argparse import Namespace
from typing import Dict, Any, Union

import numpy as np
from numpy import ndarray
from omegaconf import DictConfig

from Components.DataLayer.Loaders.LoaderInterface import LoaderInterface
from Utility.Utilities import Utilities


class InvasiveLoader(LoaderInterface):

    def __init__(self,args: Dict[str, Any]):
        super().__init__()
        self.utilities = Utilities()

    def load_data(self,args: Union[Namespace,DictConfig,Dict[str, Any]])->Union[Dict[str,Any],list,ndarray]:
        # TODO imeplement downsampling for competition dataset
        print("Loading Competition data")
        with open(args.running_args.training_data_path, "rb") as f:
            training_data = pickle.load(f)["t12"]

        with open(args.running_args.eval_data_path, "rb") as f:
            eval_data = pickle.load(f)["t12"]

        with open(args.running_args.test_data_path, "rb") as f:
            testing_data = pickle.load(f)["t12"]

        training_input = training_data["spikePow"]
        training_target = training_data["sentenceText"]
        eval_input = eval_data["spikePow"]
        eval_target = eval_data["sentenceText"]
        test_input = testing_data["spikePow"]
        test_target = testing_data["sentenceText"]

        all_sentences = training_target
        all_sentences.extend(eval_target)
        all_sentences.extend(test_target)
        max_character_length = max([len(sentence) for sentence in all_sentences])
        if not os.path.exists(args.running_args.vocab_file):
            texts = " ".join(all_sentences)
            vocab = list(set(texts))
            vocab_dict = {v: k for k, v in enumerate(vocab)}
            vocab_dict["|"] = vocab_dict[" "]
            del vocab_dict[" "]
            vocab_dict["[UNK]"] = len(vocab_dict)  # add "unknown" token
            vocab_dict["[PAD]"] = len(vocab_dict)
            with open(args.running_args.vocab_file, 'w') as vocab_file:
                json.dump(vocab_dict, vocab_file)


        training_input = [self.utilities.reshape_custom(data, np.array(data).shape[-1]) for data in training_input]
        eval_input = [self.utilities.reshape_custom(data, np.array(data).shape[-1]) for data in eval_input]
        test_input = [self.utilities.reshape_custom(data, np.array(data).shape[-1]) for data in test_input]
        training_input = self.utilities.format_to_numpy(training_input)
        eval_input = self.utilities.format_to_numpy(eval_input)
        test_input = self.utilities.format_to_numpy(test_input)

        dataset = {
            "training_input": training_input,
            "training_target": training_target,
            "eval_input": eval_input,
            "eval_target": eval_target,
            "test_input": test_input,
            "test_target": test_target,
            "max_length": int(args.running_args.max_length),
            "electrode_num": args.running_args.electrode_num,
            "max_character_length": max_character_length,
        }
        return dataset


