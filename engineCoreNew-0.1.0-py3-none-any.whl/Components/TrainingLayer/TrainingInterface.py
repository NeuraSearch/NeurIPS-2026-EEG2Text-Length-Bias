from abc import abstractmethod

import torch
from numpy._typing import NDArray

from Components.EvaluationLayer.LossLayer.LossInterface import LossInterface
from Components.EvaluationLayer.OptimizerLayer import OptimizerInterface
from Components.ModelLayer.DeepLearningLayer.DeepLearningModelInterface import DeepLearningModelInterface
from Components.ModelLayer.DeepLearningLayer.TransformerModelInterface import TransformerModelInterface
from Components.ModelLayer.ModelInterface import ModelInterface


class TrainingInterface():


    def __init__(
        self,
        model : ModelInterface,
        loss_fn : LossInterface,
        optimizer : OptimizerInterface,
        device="cuda" if torch.cuda.is_available() else "cpu",
        scheduler=None,
        metrics=None
    ):
        if isinstance(model, DeepLearningModelInterface) or isinstance(model,TransformerModelInterface):
            self.model = model.to(device)
        self.loss_fn = loss_fn
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.metrics = metrics or {}
        self.device = device

    @abstractmethod
    def train_step(self, batch : torch.Tensor | NDArray):
        pass

    @abstractmethod
    def validation_step(self, batch : torch.Tensor | NDArray):
        pass

    @abstractmethod
    def fit(self, train_loader, val_loader , epochs):
        pass