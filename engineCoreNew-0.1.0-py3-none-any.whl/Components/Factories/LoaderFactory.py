from Components.DataLayer.Loaders.Implementations.InvasiveLoader import InvasiveLoader
from Components.DataLayer.Loaders.Implementations.OpenMIIRFeaturesLoader import OpenMIRFeatureLoader
from Components.DataLayer.Loaders.Implementations.ZuCoDatasetLoader import ZuCoDatasetLoader
from Components.Factories.FactoryInterface import FactoryInterface


class LoaderFactory(FactoryInterface):

    def __init__(self):
        super().__init__()
        self.concrete_implemetations = {
            'ZuCo': ZuCoDatasetLoader,
            "Invasive": InvasiveLoader,
            "OpenMIRFeatures": OpenMIRFeatureLoader,
        }
