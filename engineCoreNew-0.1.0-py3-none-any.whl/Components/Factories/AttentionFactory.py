from Components.Factories.FactoryInterface import FactoryInterface


class AttentionFactory(FactoryInterface):
    def __init__(self):
        super().__init__()
        self.concrete_implemetations = {

        }