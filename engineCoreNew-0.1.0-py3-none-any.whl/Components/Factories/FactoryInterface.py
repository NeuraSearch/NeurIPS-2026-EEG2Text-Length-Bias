from abc import abstractmethod
from argparse import Namespace
from typing import Any, Dict, Union

from omegaconf import DictConfig


class FactoryInterface:

    def __init__(self):
        self.concrete_implemetations = {
            "abstract_loader": None,
        }

    @abstractmethod
    def construct_implementation(self, concrecte_implementation_name: str, args:   Namespace | dict[str, Any] | DictConfig) -> Any:
        if self.concrete_implemetations == {}:
            raise ValueError("Concrete loader not found. Please add a concrete loader to the factory.")
        if concrecte_implementation_name not in self.concrete_implemetations:
            error_string = f"Loader {concrecte_implementation_name} not found. Available loaders are: {self.concrete_implemetations.keys()}"
            raise ValueError(error_string)
        else:
            return self.concrete_implemetations[concrecte_implementation_name](args)
