from Components.Factories.FactoryInterface import FactoryInterface


class EvaluationFactory(FactoryInterface):
    def __init__(self):
        super().__init__()
        self.concrete_implemetations = {

        }