from Components.Factories.FactoryInterface import FactoryInterface


class SplitterFactory(FactoryInterface):
    def __init__(self):
        super().__init__()
        self.concrete_implemetations = {

        }