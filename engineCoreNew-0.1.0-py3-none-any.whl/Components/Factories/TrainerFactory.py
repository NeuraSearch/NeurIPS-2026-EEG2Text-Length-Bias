from argparse import Namespace
from typing import Union, Dict, Any

from omegaconf import DictConfig

from Components.Factories.FactoryInterface import FactoryInterface


class TrainerFactory(FactoryInterface):
    def __init__(self):
        super().__init__()
        self.concrete_implemetations = {
        }
    def construct_implementation(self, concrecte_implementation_name: str, args: Union[Namespace,DictConfig,Dict[str, Any]]) -> Any:
        if self.concrete_implemetations == {}:
            raise ValueError("Concrete loader not found. Please add a concrete loader to the factory.")
        if concrecte_implementation_name not in self.concrete_implemetations:
            error_string = f"Loader {concrecte_implementation_name} not found. Available loaders are: {self.concrete_implemetations.keys()}"
            raise ValueError(error_string)
        if "model" not in args:
            raise ValueError("Model not found in the arguments. Please add a model to the arguments.")
        else:
            return self.concrete_implemetations[concrecte_implementation_name](args.model)


