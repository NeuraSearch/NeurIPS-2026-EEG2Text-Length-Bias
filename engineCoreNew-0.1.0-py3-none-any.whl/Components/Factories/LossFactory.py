from Components.Factories.FactoryInterface import FactoryInterface


class LossFactory(FactoryInterface):
    def __init__(self):
        super().__init__()
        self.concrete_implemetations = {

        }