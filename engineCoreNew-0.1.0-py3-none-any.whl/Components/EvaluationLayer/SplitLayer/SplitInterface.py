from abc import abstractmethod
from argparse import Namespace
from typing import Any

import torch
from numpy._typing import NDArray
from omegaconf import DictConfig


class SplitInterface:

    def __init__(self,args :  Namespace | dict[str, Any] | DictConfig):
        self.args = args

    @abstractmethod
    def split(self,data : dict[str, Any] | NDArray | torch.tensor ,args :  Namespace | dict[str, Any] | DictConfig) -> NDArray | torch.tensor | Any:
        pass