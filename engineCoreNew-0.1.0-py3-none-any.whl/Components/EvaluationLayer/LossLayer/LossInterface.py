from abc import abstractmethod
from argparse import Namespace
from typing import Any

import torch
import torch.nn as nn
from omegaconf import DictConfig


class LossInterface(nn.Module):
    def __init__(self):
        super().__init__()

    @abstractmethod
    def forward(self, predictions, targets, args:   Namespace | dict[str, Any] | DictConfig):
        """
        predictions: model outputs
        targets: ground truth labels
        returns: scalar loss
        """
        pass