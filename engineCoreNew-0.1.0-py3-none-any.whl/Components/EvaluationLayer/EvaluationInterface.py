from abc import abstractmethod
from argparse import Namespace
from typing import Any

import torch
from numpy._typing import NDArray
from omegaconf import DictConfig
from torch import nn

from new_engine_structure.Core.Components.EvaluationLayer.LossLayer.LossInterface import LossInterface
from new_engine_structure.Core.Components.EvaluationLayer.OptimizerLayer import OptimizerInterface
from new_engine_structure.Core.Components.EvaluationLayer.SplitLayer.SplitInterface import SplitInterface
from new_engine_structure.Core.Components.ModelLayer.ModelInterface import ModelInterface
from new_engine_structure.Core.Components.TrainingLayer.TrainingInterface import TrainingInterface


class EvaluationInterface:

    def __init__(self,args : Namespace | dict[str, Any] | DictConfig):
        self.args = args

    @abstractmethod
    def evaluate(self, data : dict[str, Any] | NDArray | torch.tensor,
                 model : ModelInterface,
                 splitter : SplitInterface,
                 trainer : TrainingInterface,
                 optimizer: OptimizerInterface | nn.Module = None,
                 loss: LossInterface | nn.Module = None,
                 ):
        pass

    def checkCompatibility(self, model : ModelInterface,
                           optimizer : OptimizerInterface,
                           loss : LossInterface,
                           splitter : SplitInterface):
        pass