
from abc import abstractmethod
import torch
from torch.optim import Optimizer
from typing import Dict, Any, Tuple, Optional

class CustomOptimizer(Optimizer):
    def __init__(self, params, defaults):
        super(CustomOptimizer, self).__init__(params, defaults)
        pass

    @abstractmethod
    def step(self, closure: Any) -> Any:
        """
        Abstract method to update the model parameters, given the loss function.


        :param: closure: The loss function to be minimized.
        :return: The loss value.
        """
        pass