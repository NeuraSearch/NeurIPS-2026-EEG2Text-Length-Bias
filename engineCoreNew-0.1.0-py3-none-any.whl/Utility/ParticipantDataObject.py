import random

import numpy as np


class ParticipantDataObject:

    def __init__(self, ParticipantDf, SubjectNumber):
        self.ParticipantDf = ParticipantDf
        self.SubjectNumber = SubjectNumber


    def get_data(self):
        return self.ParticipantDf

    def get_subject_number(self):
        return self.SubjectNumber

    def get_repetitions(self, Data):
        song_size_in_rows = 20
        n = 0
        Repetition_List = []
        while n + song_size_in_rows <= len(Data):
            Repetition = Data.iloc[n:n + song_size_in_rows]
            Repetition_List.append(Repetition)
            n += song_size_in_rows
        random.shuffle(Repetition_List)
        return Repetition_List

    def create_overlap_window(self, Repetition, window_size):  # Creates a rolling window over a given song repetition block
        n = 0
        SequenceArr = []
        LabelArr = []
        while n + window_size <= len(Repetition):
            Sequence = Repetition.iloc[n:n + window_size]
            Label = Sequence['Label'].iloc[0]
            Sequence = Sequence.drop(columns=['Label'])
            SequenceArr.append(Sequence)
            LabelArr.append(Label)
            n += 1

        return SequenceArr, LabelArr

    def create_X_Y(self, window_size):
        Data = self.ParticipantDf
        Repetition_List = self.get_repetitions(Data)
        X = []
        Y = []
        for x in Repetition_List:
            SequenceArr, LabelArr = self.create_overlap_window(x, window_size)
            X = X + SequenceArr
            Y = Y + LabelArr

        return np.array(X), np.array(Y)