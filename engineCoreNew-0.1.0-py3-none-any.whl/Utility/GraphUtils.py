from typing import Union, Any

import numpy as np
import wandb
from matplotlib import pyplot as plt
import shap

class GraphUtils():

    def __init__(self):
        pass


    def plot_shap(self,shap_args:Union[dict,None], save_directory:str, show:bool=False, wandb_obj:Any=None)->None:
        """
        Function to plot the shape of a tensor

        Args:
            shape: The shape of the tensor

        Returns:
            None
        """
        shap_values_explainer = shap_args["explainer"]
        X_Test = shap_args["test_data"]
        shap.summary_plot(shap_values_explainer.mean(axis=-1), X_Test, feature_names=shap_args["feature_names"], show=False,
                          max_display=int(shap_args["max_display"]))
        plt.gcf().set_size_inches(shap_args["width"], shap_args["height"])
        plt.tight_layout()
        plt.savefig(f"{save_directory}/SHAP-summary-explainer.png")
        if show:
            plt.show()
        plt.clf()
        plt.cla()

        if wandb_obj is not None:
            wandb_obj.log({"shap_summary_plot": wandb.Image(f"{save_directory}/SHAP-summary-explainer.png")})

        # samples x features x classes

        shap.plots.bar(shap_values_explainer.mean(2)[0], max_display=int(shap_args["max_display"]), show=False)
        plt.gcf().set_size_inches(shap_args["width"], shap_args["height"])
        plt.tight_layout()
        plt.savefig(f"{save_directory}/SHAP-bar-explainer.png")
        if show:
            plt.show()
        plt.clf()
        plt.cla()

        if wandb_obj is not None:
            wandb_obj.log({"shap_bar_plot": wandb.Image(f"{save_directory}/SHAP-bar-explainer.png")})

        shap.plots.violin(shap_values_explainer.mean(2), features=X_Test, plot_type="layered_violin", show=False,
                          max_display=int(shap_args["max_display"]))
        plt.gcf().set_size_inches(shap_args["width"], shap_args["height"])
        plt.tight_layout()
        plt.savefig(f"{save_directory}/SHAP-bar-violin.png")
        if show:
            plt.show()
        plt.clf()
        plt.cla()

        if wandb_obj is not None:
            wandb_obj.log({"shap_violin_plot": wandb.Image(f"{save_directory}/SHAP-bar-violin.png")})

    def plot_val_training_loss(self,training_loss:Union[list,np.ndarray], validation_loss:Union[list,np.ndarray], save_directory:str, show:bool=False, wandb_obj:Any=None)->None:
        plt.plot(training_loss)
        plt.plot(validation_loss)
        plt.title('model loss')
        plt.ylabel('loss')
        plt.xlabel('epoch')
        plt.legend(['Train', 'Validation'], loc='upper left')
        plt.savefig(save_directory)
        if wandb_obj is not None:
            wandb_obj.log({"result_plot": wandb.Image(save_directory)})
        if show:
            plt.show()