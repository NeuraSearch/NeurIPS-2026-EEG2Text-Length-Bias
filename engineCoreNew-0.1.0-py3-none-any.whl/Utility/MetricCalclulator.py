from argparse import Namespace
from typing import Union, Dict, Any, List

from numpy import ndarray
from omegaconf import OmegaConf
from pandas import DataFrame
from sklearn.metrics import f1_score, accuracy_score, precision_score, recall_score, r2_score
from sympy import evaluate
from torch import tensor
from torchmetrics.text import CharErrorRate
import evaluate


class MetricCalculator:
    def __init__(self):
        print("Initializing MetricCalculator class")

    def calcluate_results(self,args:Union[Dict[str,Any],dict],predictions:Union[list,dict,DataFrame,ndarray,tensor],labels:Union[list,dict,DataFrame,ndarray,tensor])->dict:
        """
        Function to calculate the results of the model

        :param args: The arguments to be used for calculating the results
        :return: The results of the model
        """
        results = {

        }

        average="binary"
        if "average" in args:
            average=args["average"]
        if "f1-score" in args["metrics"]:
            results["f1-score"] = self.f1_scorer(predictions, labels, average)
        if "accuracy" in args["metrics"]:
            results["accuracy"] = self.accuracy_scorer(predictions, labels)
        if "precision" in args["metrics"]:
            results["precision"] = self.precision_scorer(predictions, labels, average)
        if "recall" in args["metrics"]:
            results["recall"] = self.recall_scorer(predictions, labels, average)
        if "r2" in args["metrics"]:
            results["r2"] = self.r2_scorer(predictions, labels)
        if "wer" in args["metrics"]:
            results["wer"] = self.wer_calculation(predictions, labels)
        if "cer" in args["metrics"]:
            results["cer"] = self.cer_calculation(predictions, labels)
        return results

    def f1_scorer(self,predictions, labels, average):
        """
        Creator : zenon
        Args:
                predictions:  The predictions made by the model
                gold_standard: The true labels

        Returns:
                The f1 score
        """
       
        return f1_score(predictions, labels, average=average)


    def accuracy_scorer(self, predictions, labels):
        """
        Creator : zenon
        Args:
                estimator: The estimator to use to make predictions
                predictions:  The data to make predictions on
                labels:  The true labels

        Returns:
                The accuracy score
        """
        
        return accuracy_score(predictions, labels)

    def sensitivity_scorer(self,TP, FN):
        """
        Creator : zenon
        Args:
            TP: true positives
            FN: false negatives

        Returns:
            The sensitivity score
        """
        return TP / (TP + FN)

    def specificity_scorer(self,TN, FP):
        """
        Creator : zenon
        Args:
            TN: true negatives
            FP: false positives

        Returns:
            The specificity score
        """
        return TN / (TN + FP)

    def far_scorer(self,FP, TN):
        """
        Creator : zenon
        Args:
            FP: false positives
            TN: true negatives

        Returns:
            The false alarm rate score
        """
        return FP / (FP + TN)

    def frr_scorer(self,FN, TP):
        """
        Creator : zenon
        Args:
            FN: false negatives
            TP: true positives

        Returns:
            The false rejection rate score
        """
        return FN / (FN + TP)

    def precision_scorer(self,predictions, labels,  average):
        """
                Creator : zenon
                Args:
                        estimator: The estimator to use to make predictions
                        predictions:  The data to make predictions on or the actual predictions depending if the estimator is provided
                        labels:  The true labels

                Returns:
                        The precision score
        """
        
        return precision_score(predictions, labels, average=average)

    def recall_scorer(self,predictions, labels, average):
        """
                        Creator : zenon
                        Args:
                                estimator: The estimator to use to make predictions
                                predictions:  The data to make predictions on or the actual predictions depending if the estimator is provided
                                labels:  The true labels

                        Returns:
                                The recall score
                """
        
        return recall_score(predictions, labels, average=average)

    def r2_scorer(self,predictions, labels):
        """
                        Creator : zenon
                        Args:
                                estimator: The estimator to use to make predictions
                                predictions:  The data to make predictions on or the actual predictions depending if the estimator is provided
                                labels:  The true labels

                        Returns:
                                The r2 score
                """
        
        return r2_score(labels, predictions)

    

    def wer_calculation(self,preds_str:List[str], labels_str:List[str]):
        wer_metric = evaluate.load("wer")
        wer = wer_metric.compute(predictions=preds_str, references=labels_str)

        return wer

    def cer_calculation(self,preds:List[str], targets:List[str]):
        cer = CharErrorRate()
        cer_error = cer(preds, targets)

        return cer_error
        