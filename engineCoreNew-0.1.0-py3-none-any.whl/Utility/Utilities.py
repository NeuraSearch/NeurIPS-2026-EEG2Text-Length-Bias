from argparse import Namespace
from datetime import datetime
from typing import Union, Tuple, Any, Dict

import numpy as np
import wandb
from matplotlib import pyplot as plt
from omegaconf import ListConfig
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader

from Utility.FileCrawler import FileCrawler


class Utilities:

    def __init__(self):
        print("Initializing Utility class")
        self.file_crawler = FileCrawler()

    def remove_nan(self,list_in_question:Union[list,np.ndarray])->list:
        if type(list_in_question) != list and type(list_in_question) != np.ndarray:
            return []
        list_to_return = [x for x in list_in_question if str(x) != 'nan']
        return list_to_return

    def dim(self,a:Union[list,np.ndarray])->list:
        try:
            if (not type(a) == list and not type(a) == np.ndarray and not type(a) == np.array and not type(a) == ListConfig):
                return []
            if len(a) == 0:
                return [len(a)]
            return [len(a)] + self.dim(a[0])
        except:
            return []

    def format_to_numpy(self,entries:Union[list,np.ndarray])->Union[np.ndarray,list]:
        for entry_index, entry in enumerate(entries):
            if type(entry) == list:
                entries[entry_index] = np.array(entry)
        return entries
    def reshape_custom(self,entry:Union[list,np.ndarray], loop_dimension:int)->list:

        new_entry = []
        for i in range(loop_dimension):
            try:
                if (type(entry) == list):
                    entry = np.array(entry)
                new_entry.append(entry[:, i])
            except:
                print(f"Type of entry:{type(entry)}")
                dimensions = self.dim(entry)
                print(f"Dimensions of entry:{dimensions}")
        return new_entry
    def train_test_split_custom(self,input_data:Union[list,np.ndarray], targets:Union[list,np.array], training_model:str, mode:str)\
            ->Tuple[Union[list,np.ndarray],Union[list,np.ndarray],Union[list,np.ndarray],Union[list,np.ndarray],Union[list,np.ndarray],Union[list,np.ndarray]]:
        if training_model == "decoder":
            if mode == "one_sentence":
                pass
            else:
                training_input, test_input, training_target, test_target = train_test_split(input_data, targets,
                                                                                            test_size=0.2,
                                                                                            random_state=42)
                eval_input, test_input, eval_target, test_target = train_test_split(test_input, test_target,
                                                                                    test_size=0.5,
                                                                                    random_state=42)
                return training_input, test_input, training_target, test_target, eval_input, eval_target
        else:
            if mode == "one_sentence":
                pass
            else:
                training_input, test_input, training_target, test_target = train_test_split(input_data, targets,
                                                                                            test_size=0.2,
                                                                                            random_state=42)
                return training_input, test_input, training_target, test_target, [], []


    def get_start_end_of_tokens(self, tokenized_sentence:Union[list,np.ndarray], space_sentence:Union[list,np.ndarray])->list:
        """
        creator : zenon
        When words are tokenized from the tokenizer, they can be split into multiple tokens. But don't represent the actual words in the sentence.
        This method returns the start and end of each token in the sentence in terms of which tokens represent which words in the sentence
        Args:
            tokenized_sentence: The tokenized sentence from the tokenizer
            space_sentence: The same sentence tokenized using the space delimiter

        Returns:
            The start and end of each token in the sentence in terms of which tokens represent which words in the sentence
        """
        index_of_space = 0
        windows = []
        start = 0
        end = 0
        word = ""
        for token in tokenized_sentence:
            real_token = token.replace("Ġ", "")
            word += real_token
            if word == space_sentence[index_of_space]:
                index_of_space += 1
                windows.append({"start": start, "end": end})
                end += 1
                start = end

                word = ""
            else:

                end += 1
        return windows

    def perform_checking_and_remove_nan(self,fixations:Union[list,np.ndarray])->list:
        if fixations is None:
            return []
        fixations = self.remove_nan(fixations)
        if len(fixations) == 0:
            return []
        return fixations



    def create_save_file_name_from_dict(self,dictionary:Union[Namespace,Dict[str,Any]])->Tuple[int,str]:
        """
        Creator:Zenon
        Args:
            dictionary: The dictionary to be converted to a file name

        Returns:
            A file name from the dictionary
        """
        file_name = ""
        file_name = str(datetime.now())
        for key in dictionary:
            value = dictionary[key]
            if type(value) == dict:
                for key2 in value:
                    file_name += f"{key2}_{value[key2]}_"
            else:
                file_name += f"{key}_{dictionary[key]}_"
        return hash(file_name), file_name
    def generate_file_hash(self,config:Union[Namespace,Dict[str,Any]], sub_directory:str="runs", main_directory:str=None)->Tuple[str,int]:
        if "save_file_name" not in config:

            save_file_name_hash, save_file_name = self.create_save_file_name_from_dict(config)
            if save_file_name_hash < 0:
                save_file_name_hash = save_file_name_hash * -1
                save_file_name_hash += 1
        else:
            save_file_name_hash = config["save_file_name"]
        if main_directory is None:
            save_directory = f"{config['operational_parameters']['save_directory']}/{sub_directory}/{save_file_name_hash}"
        else:
            save_directory = f"{main_directory}/{sub_directory}/{save_file_name_hash}"
        return save_directory, save_file_name_hash

    def pad_entry(self,entry:Union[list,np.ndarray], max_length:int, electrode_num:int=105)->Union[list,np.ndarray]:
        dimensions = self.dim(entry)
        try:
            recording_index = np.where(np.array(dimensions) != electrode_num)[0][0]
        except:
            recording_index = -1
        if recording_index != -1:
            if recording_index != 0:
                entry = self.reshape_custom(entry, dimensions[1])
        if len(entry) > max_length:
            entry = entry[:max_length]
        else:
            if len(dimensions) == 1:
                entry = np.pad(entry, (0, max_length - len(entry)), 'constant')
            else:
                entry = np.pad(entry, ((0, max_length - len(entry)), (0, 0)), 'constant')
        return entry


    def create_dataloaders(self, data_list:Union[list,np.ndarray], batchsize:int, shuffle:bool=False)->Union[list,np.ndarray]:
        dataloader_list = []
        for i in data_list:
            dataloader = DataLoader(data_list[i], batch_size=batchsize, shuffle=shuffle)
            dataloader_list.append(dataloader)
        return dataloader_list