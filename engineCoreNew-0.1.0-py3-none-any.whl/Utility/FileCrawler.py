import os
import pickle
from typing import Any


class FileCrawler:

    def __init__(self):
        pass

    def find_files_by_extension(self,base_directory:str, extension:str)->list:
        """
        Find all files in a directory with a specific extension
        Args:
            base_directory: The directory to search in
            extension: the file extension to search for

        Returns:
            files: A list of files with the given extension
        """
        files_by_extension = []
        for root, dirs, files in os.walk(base_directory):
            for file in files:
                print(file)
                if file.endswith(extension):
                    files_by_extension.append(os.path.join(root, file))
        files_by_extension = [file.replace("\\", "/") for file in files_by_extension]
        return files_by_extension

    def save_pickle_file(self,data:Any, file:str)->None:
        """
        Creator : Zenon
        Save a pickle file
        Args:
            data: The data to save
            file: The file location
        """
        with open(file, "wb") as f:
            pickle.dump(data, f)