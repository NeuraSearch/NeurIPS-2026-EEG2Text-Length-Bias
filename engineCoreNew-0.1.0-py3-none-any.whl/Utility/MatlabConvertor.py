import os
import pickle
from argparse import Namespace
from typing import Dict, Any, Union

import mat73
import numpy as np
from omegaconf import DictConfig
from scipy.io import loadmat, matlab

from Utility.FileCrawler import FileCrawler


class MatlabConvertor():

    def __init__(self):
        print("Initializing Matlab convertor class")
        self.file_crawler = FileCrawler()


    def _todict(self,matobj)->Dict[str,Any]:
        """
        A recursive function which constructs from matobjects nested dictionaries
        """
        d = {}
        for strg in matobj._fieldnames:
            elem = matobj.__dict__[strg]
            if isinstance(elem, matlab.mio5_params.mat_struct):
                d[strg] = self._todict(elem)
            elif isinstance(elem, np.ndarray):
                d[strg] = self._toarray(elem)
            else:
                d[strg] = elem
        return d
    def _check_vars(self,d:Dict[str,Any])->Dict[str,Any]:
        """
        Checks if entries in dictionary are mat-objects. If yes
        todict is called to change them to nested dictionaries
        """
        for key in d:
            if isinstance(d[key], matlab.mio5_params.mat_struct):
                d[key] = self._todict(d[key])
            elif isinstance(d[key], np.ndarray):
                d[key] = self._toarray(d[key])
        return d

    def _toarray(self,ndarray:np.ndarray)->Union[list,np.ndarray]:
        """
        A recursive function which constructs ndarray from cellarrays
        (which are loaded as numpy ndarrays), recursing into the elements
        if they contain matobjects.
        """
        if ndarray.dtype != 'float64':
            elem_list = []
            for sub_elem in ndarray:
                if isinstance(sub_elem, matlab.mio5_params.mat_struct):
                    elem_list.append(self._todict(sub_elem))
                elif isinstance(sub_elem, np.ndarray):
                    elem_list.append(self._toarray(sub_elem))
                else:
                    elem_list.append(sub_elem)
            return elem_list
        else:
            return ndarray.tolist()
    def load_mat(self,filename:str)->Dict[str,Any]:
        """
        This function should be called instead of direct scipy.io.loadmat
        as it cures the problem of not properly recovering python dictionaries
        from mat files. It calls the function check keys to cure all entries
        which are still mat-objects
        """
        try:
            data = loadmat(filename, struct_as_record=False, squeeze_me=True)
        except:
            data = mat73.loadmat(filename)
        return self._check_vars(data)

    def format_data_per_key(self,keys:Union[list,np.ndarray], data:Dict[str,Any])->Dict[str,Any]:
        temp_data = {}
        for key in keys:
            temp_data[key] = data[key]
        return temp_data
    def convert_matlab_to_json(self,args: Union[Namespace,DictConfig])->None:
        if os.path.isdir(args.path_to_mat_file):
            files = self.file_crawler.find_files_by_extension(args.path_to_mat_file, ".mat")
        else:
            files = [args.path_to_mat_file]

        os.makedirs(args.output, exist_ok=True)
        log_file_path = os.path.join(args.output, "log.txt")
        log_f = open(log_file_path, "w")
        print(f"Found {len(files)} files")
        whole_subject_dictionary = {}
        for file in files:
            subject_name = file.split("/")[-1].split(".")[0]
            subject_name = subject_name.split("_")[0]
            subject_name = subject_name.replace("results", "")
            try:
                data = self.load_mat(file)
            except Exception as e:
                log_f.write(f"Error loading file {file}: {e}\n")
                log_f.write(f"The exception was {e}\n")
                continue

            # json_output_path = os.path.join(args.output, f"{subject_name}.json")
            pickle_output_path = os.path.join(args.output, f"{subject_name}.pickle")
            data = self.format_data_per_key(args.keys.split(","), data)
            with open(pickle_output_path, "wb") as f:
                pickle.dump(data, f)

            # with open(pickle_output_path, "w") as f:
            #     json.dump(data["sentenceData"], f, indent=4, default=numpy_encoder.default)
            if subject_name in whole_subject_dictionary:
                for key in data:
                    whole_subject_dictionary[subject_name][key].extend(data[key])
            else:
                whole_subject_dictionary[subject_name] = data
        whole_output_path = os.path.join(args.output, "whole_subject_dictionary.json")
        whole_output_path_pickle = os.path.join(args.output, "whole_subject_dictionary.pickle")

        self.file_crawler.save_pickle_file(whole_subject_dictionary, whole_output_path_pickle)
        # save_json_file(whole_subject_dictionary, whole_output_path)
        log_f.close()