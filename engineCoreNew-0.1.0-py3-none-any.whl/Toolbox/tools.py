from argparse import Namespace

from omegaconf import DictConfig


def convert_args_to_dict(args : Namespace | DictConfig) -> dict:
    if isinstance(args, Namespace):
        return vars(args)
    if isinstance(args, DictConfig):
        return vars(args)