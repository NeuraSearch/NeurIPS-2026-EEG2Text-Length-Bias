import os
from argparse import Namespace
from typing import Union, Dict, Any

import numpy as np
import wandb
from dotenv import load_dotenv
from omegaconf import DictConfig
from wandb.sdk.lib import RunDisabled
from wandb.sdk.wandb_run import Run

from Toolbox.ResultsLogger.WandbInitializerInterface import WandbInitializerInterface


class AbstractWandbInitializer(WandbInitializerInterface):
    def __init__(self):
        super().__init__()
        print("Initializing wandb")

    def login(self,key:str=None)->bool:
        if key is None:
            load_dotenv()
            login = wandb.login(
                key=os.getenv("WANDB_API_KEY")
            )
            return login
        else:
            login = wandb.login(
                key=key
            )
            return login

    def initialize_wandb(self,cfg: Union[Namespace, Dict[str, Any],DictConfig]) -> Union[Run, RunDisabled]:

        self.wandb_obj =  wandb.init(
            **cfg,
        )
        return self.wandb_obj
    def log_graph_line(self,graph_key:str, title:str, training_loses:Union[list,np.ndarray], validation_loses:Union[list,np.ndarray],xname:str,keys:Union[list,np.ndarray],x_limit:int):
        #TODO Check if this is correct I don't think this a logging for just graphs
        self.wandb_obj.log(
            {
                f"{graph_key}": wandb.plot.line_series(
                    xs=list(range(x_limit)),
                    ys=[training_loses, validation_loses],
                    keys=keys,
                    title=title,
                    xname=xname,
                )
            }
        )