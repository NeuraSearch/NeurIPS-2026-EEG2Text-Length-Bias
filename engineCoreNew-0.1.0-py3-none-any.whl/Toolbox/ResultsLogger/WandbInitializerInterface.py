from abc import abstractmethod
from argparse import Namespace
from typing import Union, Dict, Any

from omegaconf import DictConfig
from wandb.sdk.lib import RunDisabled
from wandb.sdk.wandb_run import Run
class WandbInitializerInterface:

    def __init__(self):
        print("Initializing WandbInitializer class")

    @abstractmethod
    def login(self,key:str)->bool:
        pass

    def initialize_wandb(self,cfg: Union[Namespace, Dict[str, Any],DictConfig]) -> Union[Run, RunDisabled]:
        pass